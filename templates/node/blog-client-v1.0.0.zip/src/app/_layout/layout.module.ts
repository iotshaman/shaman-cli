import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SidebarModule } from 'primeng/sidebar';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SpinnerComponent } from './spinner/spinner.component';

import { AuthService } from '../_shared/services/auth/auth.service';
import { SidebarService } from './sidebar/sidebar.service';
import { SpinnerService } from './spinner/spinner.service';

@NgModule({
  imports: [
    CommonModule,
    SidebarModule,
    ProgressSpinnerModule,
    FontAwesomeModule
  ],
  declarations: [
    HeaderComponent,
    SidebarComponent,
    SpinnerComponent
  ],
  providers: [
    AuthService,
    SidebarService,
    SpinnerService
  ],
  exports: [
    HeaderComponent,
    SidebarComponent,
    SpinnerComponent
  ]
})
export class LayoutModule { }
