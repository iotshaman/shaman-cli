import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { faHome, faUsers, faFileSignature, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';

import { SidebarService } from './sidebar.service';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import { AuthService } from 'src/app/_shared/services/auth/auth.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.less']
})
export class SidebarComponent implements OnInit {

  isVisible: boolean = false;
  menuItems: SidebarMenuItem[] = [];

  constructor(
    private router: Router,
    private sidebarService: SidebarService,
    private authService: AuthService) { }

  ngOnInit(): void {
    this.sidebarService.isVisible.subscribe(val => this.isVisible = val);
    this.menuItems = [
      {
        label: 'Home',
        visible: true,
        icon: faHome,
        command: () => this.onClickLink(['/home'])
      },
      {
        label: 'Manage Users',
        visible: true,
        icon: faUsers,
        command: () => this.onClickLink(['/admin/manage-users'])
      },
      {
        label: 'Manage Blogs',
        visible: true,
        icon: faFileSignature,
        command: () => this.onClickLink(['/admin/manage-blogs'])
      },
      {
        label: 'Logout',
        visible: true,
        icon: faSignOutAlt,
        command: () => {
          this.authService.logout();
        }
      }
    ];
  }

  onSidebarHide = () => {
    this.sidebarService.setVisibility(false);
  }

  onClickLink = (link: string[]) => {
    this.router.navigate(link);
    this.sidebarService.setVisibility(false);
  }

}

export interface SidebarMenuItem {
  label: string;
  visible: boolean;
  icon: IconProp;
  command: (event?: any) => void;
  items?: SidebarMenuItem[];
  permission?: string;
}
