import { Injectable } from '@angular/core';
import { ToggleService } from '@iotshaman/shaman-angular';

@Injectable()
export class SidebarService extends ToggleService { }
