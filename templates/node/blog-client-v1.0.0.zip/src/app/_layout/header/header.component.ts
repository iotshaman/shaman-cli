import { Component, OnInit } from '@angular/core';
import { faBars, faUser } from '@fortawesome/free-solid-svg-icons';
import { LoggedInUser } from 'src/app/_shared/models/auth/logged-in-user';

import { AuthService } from 'src/app/_shared/services/auth/auth.service';
import { SidebarService } from '../sidebar/sidebar.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.less']
})
export class HeaderComponent implements OnInit {

  loggedIn: boolean;
  user: LoggedInUser;
  icons = {
    bars: faBars,
    user: faUser
  }

  constructor(
    private authService: AuthService,
    private sidebarService: SidebarService
  ) { }

  ngOnInit(): void {
    this.authService.loggedInUser.subscribe(user => {
      this.user = user;
    });
    this.authService.isLoggedIn.subscribe(loggedIn => {
      if (!loggedIn) this.user = null;
    })
  }

  toggleSidebar = () => {
    this.sidebarService.toggleVisibility();
  }

  onClickLogin = () => {
    this.authService.login();
  }

}
