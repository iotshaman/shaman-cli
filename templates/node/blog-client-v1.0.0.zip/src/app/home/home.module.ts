import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { BlogService } from '../_shared/services/blog.service';
import { BlogPreviewCardComponent } from './blog-preview-card/blog-preview-card.component';

import { CardModule } from 'primeng/card';


@NgModule({
  declarations: [
    HomeComponent,
    BlogPreviewCardComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    CardModule
  ],
  providers: [
    BlogService
  ]
})
export class HomeModule { }
