import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IBlog } from 'src/app/_shared/models/blog.model';

@Component({
  selector: 'app-blog-preview-card',
  templateUrl: './blog-preview-card.component.html',
  styleUrls: ['./blog-preview-card.component.less']
})
export class BlogPreviewCardComponent implements OnInit {
  @Input() blog: IBlog;

  constructor(private router: Router) { }

  ngOnInit(): void { }

  onBlogClick = () => {
    let filename = this.blog.filename;
    this.router.navigate([`/blogs/${filename}`]);
  }

}
