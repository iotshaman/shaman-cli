import { Component, OnInit } from '@angular/core';
import { SpinnerService } from '../_layout/spinner/spinner.service';
import { IBlog } from '../_shared/models/blog.model';
import { BlogService } from '../_shared/services/blog.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less']
})
export class HomeComponent implements OnInit {

  blogs: IBlog[];

  constructor(
    private spinnerService: SpinnerService,
    private blogService: BlogService) { }

  ngOnInit(): void {
    this.spinnerService.startSpinner();
    this.blogService.getAllPublishedBlogs().subscribe(blogs => {
      this.blogs = blogs;
      this.spinnerService.stopSpinner();
    });
  }

}
