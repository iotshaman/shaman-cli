import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SpinnerService } from '../_layout/spinner/spinner.service';
import { IBlog } from '../_shared/models/blog.model';
import { BlogService } from '../_shared/services/blog.service';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.less']
})
export class BlogsComponent implements OnInit {

  blog: IBlog;

  constructor(
    private router: Router,
    private blogService: BlogService,
    private spinnerService: SpinnerService) { }

  ngOnInit(): void {
    this.spinnerService.startSpinner();
    let filename = this.router.url.split('/')[2];
    this.blogService.getBlog(filename).subscribe(blog => {
      this.blog = blog;
      this.spinnerService.stopSpinner();
    });
  }

}
