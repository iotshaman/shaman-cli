import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ApiService, ConfigService } from "@iotshaman/shaman-angular";
import { map, Observable } from "rxjs";
import { AppConfig } from "../models/app.config";
import { IBlog } from "../models/blog.model";

@Injectable()
export class BlogService extends ApiService {
    protected apiBaseUri: Observable<string>;

    constructor(
        httpClient: HttpClient, config: ConfigService<AppConfig>) {
        super(httpClient);
        this.apiBaseUri = config.currentConfiguration
            .pipe(map(config => config.apiBaseUri));
    }

    getAllBlogs = (): Observable<IBlog[]> => {
        return this.get('/blog');
    }

    getAllPublishedBlogs = (): Observable<IBlog[]> => {
        return this.get('/blog/published');
    }

    getBlog = (filename: string): Observable<IBlog> => {
        return this.get(`/blog/${filename}`);
    }

    deleteBlog = (fileName: string): Observable<null> => {
        return this.delete(`/blog/${fileName}`);
    }

    addBlog = (title: string): Observable<IBlog> => {
        let body = { title };
        return this.put('/blog', body);
    }

    updateBlog = (blog: IBlog): Observable<IBlog> => {
        let body = { blog };
        return this.post('/blog', body);
    }
}