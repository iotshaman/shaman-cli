import { Observable, ReplaySubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Injectable, Optional, Inject } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';
import { ConfigService, ApiService } from '@iotshaman/shaman-angular';
import _jwt_decode from 'jwt-decode';
const JWT = _jwt_decode;

import { LoggedInUser } from '../../models/auth/logged-in-user';
import { PERMISSIONS_TOKEN } from '../../models/auth/permissions.token';
import { Router } from '@angular/router';
import { AppConfig } from '../../models/app.config';
import { AccessToken } from 'src/app/login/access-token';

@Injectable()
export class AuthService extends ApiService {
  protected apiBaseUri: Observable<string>;
  private storage: Storage = window.localStorage;
  protected isLoggedInSubject = new ReplaySubject<boolean>(1);
  protected loggedInUserSubject = new ReplaySubject<LoggedInUser>(1);

  constructor(
    httpBackend: HttpBackend,
    private router: Router,
    private configService: ConfigService<AppConfig>,
    @Optional() @Inject(PERMISSIONS_TOKEN) private appPermissions: string[]
  ) {
    super(new HttpClient(httpBackend));
    this.apiBaseUri = configService.currentConfiguration.pipe(
      map((config) => config.apiBaseUri)
    );
    if (!this.appPermissions) this.appPermissions = [];
    this.restoreLogin();
  }

  /**
   * Observable to determine if user is logged in. Initial value is false.
   *
   * @returns Observable<boolean>
   */
  public isLoggedIn = this.isLoggedInSubject.asObservable();

  /**
   * Observable that emits the details for a logged in user.
   *
   * @returns Observable<LoggedInUser>
   */
  public loggedInUser = this.loggedInUserSubject.asObservable();

  /**
   * Returns user's access token
   *
   * @returns string
   */
  public get accessToken(): string {
    return localStorage.getItem('accessToken');
  }

  login = (): void => {
    this.router.navigate(['/login']);
  };

  logout = (): void => {
    this.storage.removeItem('accessToken');
    window.location.href = '/';
  };

  checkAuthorization = (response: Response) => {
    if (response.status == 403) {
      localStorage.removeItem('accessToken');
      return (window.location.href = '/');
    }
    return response;
  };

  notAuthorized = (): void => {
    window.location.href = '/';
  };

  handleLogin = (accessToken: AccessToken): Promise<void> => {
    let token = JWT(accessToken.token);
    if (!this.hasPermissions(token)) {
      this.isLoggedInSubject.next(false);
      return null;
    }
    this.isLoggedInSubject.next(true);
    let user = new LoggedInUser(token);
    this.loggedInUserSubject.next(user);
    return this.storeAccessToken(accessToken);
  };

  private storeAccessToken = (accessToken: AccessToken): Promise<void> => {
    return new Promise((res) => {
      localStorage.setItem('accessToken', accessToken.token);
      res();
    });
  };

  private restoreLogin = () => {
    if (!this.accessToken) return;
    let accessToken: any = JWT(this.accessToken);
    let accessTokenExpires = new Date(Date.parse(accessToken.expires));
    if (new Date(Date.now()) >= accessTokenExpires) return;
    this.isLoggedInSubject.next(true);
    this.loggedInUserSubject.next(new LoggedInUser(accessToken));
  };

  private hasPermissions = (token) => {
    return this.appPermissions.every((p) => token.permissions.indexOf(p) > -1);
  };
}
