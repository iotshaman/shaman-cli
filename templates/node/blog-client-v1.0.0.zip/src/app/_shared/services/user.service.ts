import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ApiService, ConfigService } from "@iotshaman/shaman-angular";
import { map, Observable } from "rxjs";
import { AppConfig } from "src/app/_shared/models/app.config";
import { IUser } from "src/app/_shared/models/user.model";

@Injectable()
export class UserService extends ApiService {
    protected apiBaseUri: Observable<string>;

    constructor(
        httpClient: HttpClient, config: ConfigService<AppConfig>) {
        super(httpClient); 
        this.apiBaseUri = config.currentConfiguration
            .pipe(map(config => config.apiBaseUri));
    }

    getAllUsers = (): Observable<IUser[]> => {
        return this.get('/user');
    }

    deleteUser = (email: string): Observable<null> => {
        return this.delete(`/user/${email}`);
    }

    addUser = (name: string, email: string, password: string): Observable<IUser> => {
        let body = { name, email, password }
        return this.put('/user', body);
    }
}