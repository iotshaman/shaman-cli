import { InjectionToken } from '@angular/core'

export const PERMISSIONS_TOKEN = new InjectionToken<string[]>('List of required permissions');
