export class AuthConfig {
  oAuthApiEndpoint: string;
}
