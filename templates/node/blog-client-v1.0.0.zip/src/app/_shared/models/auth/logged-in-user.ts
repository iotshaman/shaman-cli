export class LoggedInUser {
  email: string
  name: string;
  expires: Date;

  constructor(token: any) {
    this.email = token.email;
    this.name = token.name;
    this.expires = new Date(Date.parse(token.expires));
  }
}
