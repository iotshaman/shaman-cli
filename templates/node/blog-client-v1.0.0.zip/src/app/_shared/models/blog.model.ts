export interface IBlog {
    filename: string;
    name: string;
    title: string;
    description: string;
    author: string;
    text: string;
    html: string;
    image: string;
    published: boolean;
    tags: string;
    createdDate: Date;
    modifiedDate: Date;
    displayDate: Date;
}