export interface IUser {
    email: string;
    name: string;
    passwordHash: string;
    primary: boolean;
    temporaryPass: boolean;
}

