import { AuthConfig } from './auth/auth.config';

export class AppConfig extends AuthConfig {
    apiBaseUri: string;
}