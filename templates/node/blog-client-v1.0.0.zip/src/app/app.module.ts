import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from './_layout/layout.module';
import { ToastModule } from 'primeng/toast';

import { AuthService } from './_shared/services/auth/auth.service';
import { MessageService } from 'primeng/api'

import {
  ComponentsModule, AuthInterceptor,
  ConfigService, CONFIGURATION_FILE_PATH
} from '@iotshaman/shaman-angular';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NoopAnimationsModule,
    LayoutModule,
    ComponentsModule,
    HttpClientModule,
    ToastModule
  ],
  providers: [
    { provide: CONFIGURATION_FILE_PATH, useValue: '/assets/data/client-config.json' },
    ConfigService,
    AuthService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    MessageService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
