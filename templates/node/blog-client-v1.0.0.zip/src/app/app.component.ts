import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less', '../styles/styles.less']
})
export class AppComponent {
  title = 'nrg-client';
}
