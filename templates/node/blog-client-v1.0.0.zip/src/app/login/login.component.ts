import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { faUser } from '@fortawesome/free-solid-svg-icons';

import { LoginService } from './login.service';
import { AuthService } from '../_shared/services/auth/auth.service';
import { AccessToken } from './access-token';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {

  email: string;
  password: string;
  newPassword: string;
  confirmPassword: string;
  processing: boolean = false;
  complete: boolean = false;
  temporaryPassFormVisible: boolean = false;
  icons = {
    user: faUser
  }
  private accessToken: AccessToken;

  constructor(
    private router: Router,
    private authService: AuthService,
    private loginService: LoginService,
    private messageService: MessageService
  ) { }

  ngOnInit(): void { }

  get invalidForm() {
    return !this.email || !this.password;
  }

  get invalidTemporaryPasswordForm() {
    if (!this.newPassword || !this.confirmPassword) return true;
    return this.newPassword != this.confirmPassword;
  }

  get signInButtonLabel() {
    if (this.complete) return 'Redirecting...';
    if (this.processing) return 'Processing...';
    return 'Sign In';
  }

  get signUpButtonLabel() {
    return 'Sign Up';
  }

  onSubmitLogin = () => {
    this.processing = true;
    this.loginService.authenticateUser(this.email, this.password)
      .subscribe(accessToken => {
        this.processing = false;
        this.complete = true;
        this.accessToken = accessToken;
        if (!!accessToken.temporary) this.showTemporaryPasswordForm();
        else setTimeout(_ => this.handleSuccessfulAuthentication(accessToken), 500);
      }, _ex => {
        this.processing = false;
        this.messageService.add({
          life: 5000,
          severity: 'error',
          summary: 'Login Failed',
          detail: 'Login attempt was unsuccessful. Please try again or contact support.'
        })
      });
  }

  showTemporaryPasswordForm = () => {
    this.temporaryPassFormVisible = true;
    this.complete = false;
  }

  skipTemporaryPasswordReset = () => {
    this.handleSuccessfulAuthentication(this.accessToken);
  }

  onSubmitUpdateTemporaryPassword = () => {
    this.processing = true;
    this.loginService.updateUserPassword(this.email, this.password, this.newPassword)
      .subscribe(_ => {
        this.processing = false;
        this.complete = true;
        setTimeout(_ => this.handleSuccessfulAuthentication(this.accessToken), 1000);
      }, _ex => {
        this.processing = false;
        this.messageService.add({
          life: 5000,
          severity: 'error',
          summary: 'Password Update Failed',
          detail: 'An error occurred while updating your password. Please try again or contact support.'
        })
      });
  }

  handleSuccessfulAuthentication = (accessToken: AccessToken) => {
    this.authService.handleLogin(accessToken)
      .then(_ => this.router.navigate(['/admin']));
  }


}
