import { Injectable } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';
import { ApiService, ConfigService } from '@iotshaman/shaman-angular';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { AppConfig } from '../_shared/models/app.config';
import { AccessToken } from './access-token';

@Injectable()
export class LoginService extends ApiService {
  protected apiBaseUri: Observable<string>;

  constructor(
    httpBackend: HttpBackend,
    configService: ConfigService<AppConfig>) {
    super(new HttpClient(httpBackend));
    this.apiBaseUri = configService.currentConfiguration
      .pipe(map(config => config.apiBaseUri));
  }

  authenticateUser = (email: string, password: string)
    : Observable<AccessToken> => {
    return this.post('/login', { email, password });
  }

  updateUserPassword = (email: string, oldPassword: string, newPassword: string): Observable<void> => {
    return this.post('/login/pwd', { email, oldPassword, newPassword });
  }

}
