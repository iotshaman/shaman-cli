export class AccessToken {
  token: string;
  temporary?: boolean;
}
