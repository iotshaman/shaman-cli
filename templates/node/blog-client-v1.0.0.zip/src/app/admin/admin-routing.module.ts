import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'manage-blogs', loadChildren: () => import('./manage-blogs/manage-blogs.module')
      .then(m => m.ManageBlogsModule)
  },
  {
    path: 'manage-users', loadChildren: () => import('./manage-users/manage-users.module')
      .then(m => m.ManageUsersModule)
  },
  { path: '', redirectTo: 'manage-blogs', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
