import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PreviewBlogRoutingModule } from './preview-blog-routing.module';
import { PreviewBlogComponent } from './preview-blog.component';
import { ButtonModule } from 'primeng/button';


@NgModule({
  declarations: [
    PreviewBlogComponent
  ],
  imports: [
    CommonModule,
    PreviewBlogRoutingModule,
    ButtonModule
  ]
})
export class PreviewBlogModule { }
