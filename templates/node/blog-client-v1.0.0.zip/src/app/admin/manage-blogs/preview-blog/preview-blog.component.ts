import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SpinnerService } from 'src/app/_layout/spinner/spinner.service';
import { IBlog } from 'src/app/_shared/models/blog.model';
import { AuthService } from 'src/app/_shared/services/auth/auth.service';
import { BlogService } from 'src/app/_shared/services/blog.service';

@Component({
  selector: 'app-preview-blog',
  templateUrl: './preview-blog.component.html',
  styleUrls: ['./preview-blog.component.less'],
})
export class PreviewBlogComponent implements OnInit {
  blog: IBlog;

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private blogService: BlogService,
    private spinnerService: SpinnerService
  ) {}

  ngOnInit(): void {
    this.spinnerService.startSpinner();
    let filename = this.route.snapshot.queryParams['name'];
    this.blogService.getBlog(filename).subscribe({
      next: (blog) => {
        this.blog = blog;
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        this.authService.checkAuthorization(response);
      }
    });
  }

  onBackClick = () => {
    this.router.navigate(['..', 'edit-blog'], {
      relativeTo: this.route,
      queryParams: {
        name: this.blog.filename,
      }
    });
  };
}
