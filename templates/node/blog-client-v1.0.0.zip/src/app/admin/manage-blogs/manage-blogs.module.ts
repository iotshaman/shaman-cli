import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '@iotshaman/shaman-angular';
import { ReactiveFormsModule } from '@angular/forms';

import { ManageBlogsRoutingModule } from './manage-blogs-routing.module';
import { ManageBlogsComponent } from './manage-blogs.component';
import { BlogCardComponent } from './blog-card/blog-card.component';
import { BlogService } from 'src/app/_shared/services/blog.service';
import { AddBlogComponent } from './create-blog/create-blog.component';

import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { ConfirmationService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';


@NgModule({
  declarations: [
    ManageBlogsComponent,
    BlogCardComponent,
    AddBlogComponent
  ],
  imports: [
    CommonModule,
    ManageBlogsRoutingModule,
    ButtonModule,
    CardModule,
    ConfirmDialogModule,
    DialogModule,
    InputTextModule,
    ReactiveFormsModule,
  ],
  providers: [
    AuthService,
    BlogService,
    ConfirmationService
  ]
})
export class ManageBlogsModule { }
