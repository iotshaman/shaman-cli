import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { IBlog } from 'src/app/_shared/models/blog.model';

@Component({
  selector: 'app-blog-card',
  templateUrl: './blog-card.component.html',
  styleUrls: ['./blog-card.component.less']
})
export class BlogCardComponent implements OnInit {

  @Input() blog: IBlog;
  @Output() deleteBtnClicked = new EventEmitter();
  @Output() editBtnClicked = new EventEmitter();

  constructor(
    private confirmationService: ConfirmationService) { }

  ngOnInit(): void { }

  onDeleteClick = () => {
    this.deleteBtnClicked.emit(this.blog);
  }

  onEditClick = () => {
    this.editBtnClicked.emit(this.blog);
  }

}
