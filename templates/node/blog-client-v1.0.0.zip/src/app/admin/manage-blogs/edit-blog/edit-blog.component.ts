import { Component, HostListener, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { SpinnerService } from 'src/app/_layout/spinner/spinner.service';
import { IBlog } from 'src/app/_shared/models/blog.model';
import { AuthService } from 'src/app/_shared/services/auth/auth.service';
import { BlogService } from 'src/app/_shared/services/blog.service';

@Component({
  selector: 'app-edit-blog',
  templateUrl: './edit-blog.component.html',
  styleUrls: ['./edit-blog.component.less'],
})
export class EditBlogComponent implements OnInit {
  blog: IBlog;
  editForm: FormGroup;
  panelHeader: string;
  blogActions: MenuItem[] = [];
  formLoaded: boolean = false;
  statusOptions = [
    { key: 'Published', value: true },
    { key: 'Not Published', value: false },
  ];

  constructor(
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private blogService: BlogService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private spinnerService: SpinnerService
  ) {}

  ngOnInit(): void {
    this.spinnerService.startSpinner();
    let filename = this.route.snapshot.queryParams['name'];
    this.blogService.getBlog(filename).subscribe({
      next: (blog) => {
        this.blog = blog;
        this.panelHeader = `Edit Blog - ${blog.title}`;
        this.loadEditForm();
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        this.authService.checkAuthorization(response);
      },
    });
  }

  loadEditForm = () => {
    this.editForm = new FormGroup({
      title: new FormControl({ value: this.blog.title, disabled: true }),
      description: new FormControl(this.blog.description),
      image: new FormControl(this.blog.image),
      tags: new FormControl(this.blog.tags),
      status: new FormControl(this.blog.published),
      text: new FormControl(this.blog.text),
    });
    this.blogActions = [
      { label: 'Exit', command: () => this.exitEdit() },
      { label: 'Save', command: () => this.saveBlog() },
      { label: 'Preview', command: () => this.previewBlog() },
    ];
    this.formLoaded = true;
  };

  saveBlog = () => {
    this.spinnerService.startSpinner();
    let updatedBlog: IBlog = this.blog;
    updatedBlog.title = this.title;
    updatedBlog.description = this.description;
    updatedBlog.image = this.image;
    updatedBlog.tags = this.tags;
    updatedBlog.published = this.status;
    updatedBlog.text = this.text;
    this.blogService.updateBlog(updatedBlog).subscribe({
      next: (_blog) => {
        this.editForm.markAsPristine();
        this.messageService.add({
          life: 5000,
          severity: 'success',
          summary: 'Blog Saved',
          detail: 'Blog successfully updated',
        });
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        this.authService.checkAuthorization(response);
      },
    });
  };

  exitEdit = () => {
    let dirty = this.editForm.dirty;
    if (!dirty) return this.router.navigate(['..'], { relativeTo: this.route });
    return this.confirmationService.confirm({
      message: 'Are you sure that you want to exit without saving?',
      icon: 'pi pi-exclamation-triangle',
      accept: () => this.router.navigate(['..'], { relativeTo: this.route }),
      reject: () => {},
    });
  };

  previewBlog = () => {
    let dirty = this.editForm.dirty;
    if (dirty)
      return this.messageService.add({
        life: 5000,
        severity: 'warn',
        summary: 'Unsaved edits',
        detail: 'Blog must be saved before previewing changes.',
      });
    return this.router.navigate(['..', 'preview-blog'], {
      relativeTo: this.route,
      queryParams: {
        name: this.blog.filename,
      },
    });
  };

  get title() {
    return this.editForm.get('title').value;
  }
  get description() {
    return this.editForm.get('description').value;
  }
  get image() {
    return this.editForm.get('image').value;
  }
  get tags() {
    return this.editForm.get('tags').value;
  }
  get status() {
    return this.editForm.get('status').value;
  }
  get text() {
    return this.editForm.get('text').value;
  }
}
