import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SpinnerService } from 'src/app/_layout/spinner/spinner.service';
import { AuthService } from 'src/app/_shared/services/auth/auth.service';
import { BlogService } from 'src/app/_shared/services/blog.service';

@Component({
  selector: 'app-create-blog',
  templateUrl: './create-blog.component.html',
  styleUrls: ['./create-blog.component.less'],
})
export class AddBlogComponent implements OnInit {
  @Input() visible;
  @Output() visibleChange = new EventEmitter<boolean>();

  blogForm: FormGroup;
  submitClicked: boolean = false;

  constructor(
    private authService: AuthService,
    private blogService: BlogService,
    private spinnerService: SpinnerService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.blogForm = new FormGroup({
      blogTitle: new FormControl('', [Validators.required]),
    });
  }

  closeDialog = () => {
    this.visibleChange.emit(false);
    this.blogForm.reset();
    this.submitClicked = false;
  };

  onSubmit = () => {
    this.submitClicked = true;
    this.spinnerService.startSpinner();
    if (!this.blogForm.valid) return;
    this.blogService.addBlog(this.blogTitle.value).subscribe({
      next: (blog) => {
        this.router.navigate(['edit-blog'], {
          relativeTo: this.route,
          queryParams: {
            name: blog.filename,
          },
        });
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        this.authService.checkAuthorization(response);
      },
    });
  };

  get blogTitle() {
    return this.blogForm.get('blogTitle');
  }
}
