import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ManageBlogsComponent } from './manage-blogs.component';

const routes: Routes = [
  { path: '', component: ManageBlogsComponent },
  {
    path: 'edit-blog', loadChildren: () => import('./edit-blog/edit-blog.module')
      .then(m => m.EditBlogModule)
  },
  {
    path: 'preview-blog', loadChildren: () => import('./preview-blog/preview-blog.module')
      .then(m => m.PreviewBlogModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageBlogsRoutingModule { }
