import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/_shared/services/auth/auth.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { SpinnerService } from 'src/app/_layout/spinner/spinner.service';
import { IBlog } from 'src/app/_shared/models/blog.model';
import { BlogService } from 'src/app/_shared/services/blog.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-manage-blogs',
  templateUrl: './manage-blogs.component.html',
  styleUrls: ['./manage-blogs.component.less'],
})
export class ManageBlogsComponent implements OnInit {
  blogs: IBlog[];
  displayAddBlog: boolean = false;

  constructor(
    private authService: AuthService,
    private blogService: BlogService,
    private confirmationService: ConfirmationService,
    private spinnerService: SpinnerService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.authService.isLoggedIn.subscribe((loggedIn) => {
      if (!loggedIn) return this.authService.notAuthorized();
      this.loadBlogs();
    });
  }

  onAddBlogClick = () => {
    this.displayAddBlog = true;
  };

  editBlog = (blog: IBlog) => {
    this.router.navigate(['edit-blog'], {
      relativeTo: this.route,
      queryParams: {
        name: blog.filename,
      },
    });
  };

  confirmDeleteBlog = (blog: IBlog) => {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete this blog?',
      icon: 'pi pi-exclamation-triangle',
      accept: () => this.deleteBlog(blog),
      reject: () => {},
    });
  };

  private deleteBlog = (blog: IBlog) => {
    this.spinnerService.startSpinner();
    this.blogService.deleteBlog(blog.filename).subscribe({
      next: () => {
        this.loadBlogs();
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        return this.authService.checkAuthorization(response);
      },
    });
  };

  loadBlogs = () => {
    this.spinnerService.startSpinner();
    this.blogService.getAllBlogs().subscribe({
      next: (blogs) => {
        this.blogs = blogs;
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        return this.authService.checkAuthorization(response);
      }
    });
  };
}
