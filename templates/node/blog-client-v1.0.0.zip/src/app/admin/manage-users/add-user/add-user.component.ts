import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { SpinnerService } from 'src/app/_layout/spinner/spinner.service';
import { AuthService } from 'src/app/_shared/services/auth/auth.service';
import { UserService } from '../../../_shared/services/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.less']
})
export class AddUserComponent implements OnInit {

  @Input() visible;
  @Output() visibleChange = new EventEmitter<boolean>();
  @Output() reloadUsers = new EventEmitter();

  userForm: FormGroup;
  submitClicked: boolean = false;

  constructor(
    private authService: AuthService,
    private userService: UserService,
    private spinnerService: SpinnerService) { }

  ngOnInit(): void {
    this.userForm = new FormGroup({
      fullName: new FormControl('', [
        Validators.required,
        Validators.minLength(1)
      ]),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(1)
      ]),
      confirmPassword: new FormControl('', [
        Validators.required,
        Validators.minLength(1)
      ])
    }, { validators: this.checkPasswords });
  }

  onSubmit = () => {
    this.submitClicked = true;
    if (!this.userForm.valid) return;
    this.spinnerService.startSpinner();
    this.userService.addUser(this.fullName.value, this.email.value, this.password.value).subscribe({
      next: () => {
        this.closeDialog();
        this.reloadUsers.emit();
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        this.authService.checkAuthorization(response);
      }
    });
  }

  checkPasswords: ValidatorFn = (group: AbstractControl) => {
    let password = group.get('password').value;
    let confirmPassword = group.get('confirmPassword').value;
    return password === confirmPassword ? null : { notSame: true };
  }

  closeDialog = () => {
    this.visibleChange.emit(false);
    this.userForm.reset();
    this.submitClicked = false;
  }

  get fullName() { return this.userForm.get('fullName') }
  get email() { return this.userForm.get('email') }
  get password() { return this.userForm.get('password') }
  get confirmPassword() { return this.userForm.get('confirmPassword') }
}
