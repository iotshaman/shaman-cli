import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { IUser } from 'src/app/_shared/models/user.model';

@Component({
  selector: 'app-user-card',
  templateUrl: './user-card.component.html',
  styleUrls: ['./user-card.component.less']
})
export class UserCardComponent implements OnInit {

  @Input() user: IUser;
  @Output() deleteBtnClicked = new EventEmitter();

  constructor(
    private confirmationService: ConfirmationService) { }

  ngOnInit(): void { }

  onDeleteClick = () => {
    this.deleteBtnClicked.emit(this.user);
  }

}
