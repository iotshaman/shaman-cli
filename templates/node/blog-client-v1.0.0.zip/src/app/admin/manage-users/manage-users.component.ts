import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { SpinnerService } from 'src/app/_layout/spinner/spinner.service';
import { IUser } from 'src/app/_shared/models/user.model';
import { AuthService } from 'src/app/_shared/services/auth/auth.service';
import { UserService } from '../../_shared/services/user.service';

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.less'],
})
export class ManageUsersComponent implements OnInit {
  users: IUser[];
  displayAddUser: boolean = false;

  constructor(
    private authService: AuthService,
    private userService: UserService,
    private confirmationService: ConfirmationService,
    private spinnerService: SpinnerService,
  ) {}

  ngOnInit(): void {
    this.authService.isLoggedIn.subscribe((loggedIn) => {
      if (!loggedIn) return this.authService.notAuthorized();
      this.loadUsers();
    });
  }

  onAddUserClick = () => {
    this.displayAddUser = true;
  };

  confirmDeleteUser = (user: IUser) => {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete this user?',
      icon: 'pi pi-exclamation-triangle',
      accept: () => this.deleteUser(user),
      reject: () => {},
    });
  };

  private deleteUser = (user: IUser) => {
    this.spinnerService.startSpinner();
    this.userService.deleteUser(user.email).subscribe({
      next: () => {
        this.loadUsers();
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        return this.authService.checkAuthorization(response);
      },
    });
  };

  loadUsers = () => {
    this.spinnerService.startSpinner();
    this.userService.getAllUsers().subscribe({
      next: (users) => {
        this.users = users;
        this.spinnerService.stopSpinner();
      },
      error: (response) => {
        this.spinnerService.stopSpinner();
        return this.authService.checkAuthorization(response);
      },
    });
  };
}
