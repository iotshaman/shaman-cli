import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ManageUsersRoutingModule } from './manage-users-routing.module';
import { ManageUsersComponent } from './manage-users.component';
import { AuthService } from 'src/app/_shared/services/auth/auth.service';
import { UserService } from '../../_shared/services/user.service';
import { UserCardComponent } from './user-card/user-card.component';
import { AddUserComponent } from './add-user/add-user.component';

import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { ConfirmationService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';


@NgModule({
  declarations: [
    ManageUsersComponent,
    UserCardComponent,
    AddUserComponent
  ],
  imports: [
    CommonModule,
    ManageUsersRoutingModule,
    CardModule,
    ButtonModule,
    ConfirmDialogModule,
    DialogModule,
    InputTextModule,
    ReactiveFormsModule,
    FormsModule,
    PasswordModule
  ],
  providers: [
    AuthService,
    UserService,
    ConfirmationService
  ]
})
export class ManageUsersModule { }
