/* istanbul ignore file */
import "reflect-metadata";
import * as _path from 'path';
import * as express from 'express';
import { Container } from "inversify";

import { TYPES, CONTROLLER_TYPES } from "./app.composition.types";
import { AppConfig } from "../models/app.config";
import { ILogger, Logger } from "../logger";
import { IApiService, ApiService } from "../api.service";
import { IJsonFileService, JsonFileService } from "../services/json-file.service";
import { ApiRouter } from "../api.router";
import { HealthController } from "../controllers/health/health.controller";
import { AuthService, IAuthService } from "../services/auth.service";
import { DataContext } from "../models/data.context";
import { BlogService, IBlogService } from "../services/blog.service";
import { IUserService, UserService } from "../services/user.service";
import { BlogController } from "../controllers/blog/blog.controller";
import { LoginController } from "../controllers/login/login.controller";
import { UserController } from "../controllers/user/user.controller";
//shaman: {"lifecycle": "transformation", "args": {"type": "import", "target": "*"}}

export function Configure(config: AppConfig): Promise<Container> {
  return configureServices(new Container(), config)
    .then(container => configureRouter(container))
    .then(container => configureDataContext(container, config));
}

function configureServices(container: Container, config: AppConfig): Promise<Container> {
  container.bind<AppConfig>(TYPES.AppConfig).toConstantValue(config);
  container.bind<ILogger>(TYPES.Logger).to(Logger);
  container.bind<IApiService>(TYPES.ApiService).to(ApiService).inSingletonScope();
  container.bind<express.Application>(TYPES.ExpressApplication).toConstantValue(express());
  container.bind<IJsonFileService>(TYPES.JsonFileService).to(JsonFileService);
  container.bind<IAuthService>(TYPES.AuthService).to(AuthService);
  container.bind<IBlogService>(TYPES.BlogService).to(BlogService);
  container.bind<IUserService>(TYPES.UserService).to(UserService);
  //shaman: {"lifecycle": "transformation", "args": {"type": "compose", "target": "services"}}
  return Promise.resolve(container);
}

function configureRouter(container: Container): Promise<Container> {
  container.bind<ApiRouter>(TYPES.ApiRouter).to(ApiRouter);
  container.bind<HealthController>(CONTROLLER_TYPES.HealthController).to(HealthController);
  container.bind<BlogController>(CONTROLLER_TYPES.BlogController).to(BlogController);
  container.bind<LoginController>(CONTROLLER_TYPES.LoginController).to(LoginController);
  container.bind<UserController>(CONTROLLER_TYPES.UserController).to(UserController);
  //shaman: {"lifecycle": "transformation", "args": {"type": "compose", "target": "router"}}
  return Promise.resolve(container);
}

function configureDataContext(container: Container, config: AppConfig): Promise<Container> {
  return new Promise(res => {
    let dataPath = _path.join(__dirname, '..', '..', 'data', 'db.json')
    let context = new DataContext(dataPath);
    context.initialize();
    container.bind<DataContext>(TYPES.DataContext).toConstantValue(context);
    //shaman: {"lifecycle": "transformation", "args": {"type": "compose", "target": "datacontext"}}
    res(container);
  });
}