import * as _bcrypt from 'bcryptjs';
import { inject, injectable } from 'inversify';
import { TYPES } from '../composition/app.composition.types';
import { DataContext } from '../models/data.context';
import { User } from '../models/user';

export interface IUserService {
  getAllUsers: () => Promise<User[]>;
  getUser: (email: string) => Promise<User>;
  addUser: (email: string, name: string, password: string) => Promise<User>;
  deleteUser: (email: string) => Promise<void>;
}

@injectable()
export class UserService implements IUserService {

  constructor(
    @inject(TYPES.DataContext)
    private context: DataContext) { }

  getAllUsers = (): Promise<User[]> => {
    return Promise.resolve(
      this.context.models.users.filter(b => !!b)
    );
  }

  getUser = (email: string): Promise<User> => {
    return Promise.resolve(
      this.context.models.users.find(email)
    )
  }

  addUser = (email: string, name: string, password: string): Promise<User> => {
    let newUser = new User();
    newUser.email = email;
    newUser.name = name;
    newUser.passwordHash = _bcrypt.hashSync(password, _bcrypt.genSaltSync(8), null);
    newUser.temporaryPass = true;
    this.context.models.users.add(email, newUser);
    return this.context.saveChanges()
      .then(_ => this.context.models.users.find(email));
  }

  deleteUser = (email: string): Promise<void> => {
    return new Promise((res, err) => {
      let user = this.context.models.users.find(email);
      if (user.primary) return err(new Error("Cannot delete primary user."))
      this.context.models.users.delete(email);
      this.context.saveChanges()
        .then(_ => res())
        .catch(ex => err(ex));
    });
  }

}