export class AppConfig {
  port: string;
  dataPath: string;
  jwtSecret: string;
}