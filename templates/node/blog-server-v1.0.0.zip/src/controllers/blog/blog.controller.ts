import { Request, Response, Application, Router } from "express";
import { inject, injectable } from 'inversify';
import { IBlogService } from "../../services/blog.service";
import { RouteError } from "../../models/route-error";
import { ControllerBase } from "../controller.base";
import { IAuthService } from "../../services/auth.service";
import { TYPES } from "../../composition/app.composition.types";

@injectable()
export class BlogController extends ControllerBase {

  private router: Router;

  constructor(
    @inject(TYPES.ExpressApplication) app: Application,
    @inject(TYPES.BlogService) private blogService: IBlogService,
    @inject(TYPES.AuthService) authService: IAuthService) {
    super(authService);
    this.router = Router();
    this.router
      .use(this.authorize)
      .get('/', this.getAllBlogs)
      .get('/:filename', this.getBlog)
      .put('/', this.addBlog)
      .post('/', this.updateBlog)
      .delete('/:filename', this.deleteBlog)

      app.use('/api/blog', this.router);
  }

  getAllBlogs = (_req: Request, res: Response, next: any) => {
    this.blogService.getAllBlogs()
      .then(blogs => res.json(blogs))
      .catch((ex: Error) => next(new RouteError(ex.message, 400)));
  }

  getBlog = (req: Request, res: Response, next: any) => {
    this.blogService.getBlog(req.params['filename'])
      .then(blog => res.json(blog))
      .catch((ex: Error) => next(new RouteError(ex.message, 400)));
  }

  addBlog = (req: Request, res: Response, next: any) => {
    let author = req['_token'].name;
    this.blogService.addBlog(req.body.title, author)
      .then(blog => res.json(blog))
      .catch((ex: Error) => next(new RouteError(ex.message, 400)));
  }

  updateBlog = (req: Request, res: Response, next: any) => {
    this.blogService.updateBlog(req.body)
      .then(blog => res.json(blog))
      .catch((ex: Error) => next(new RouteError(ex.message, 400)));
  }

  deleteBlog = (req: Request, res: Response, next: any) => {
    this.blogService.deleteBlog(req.params['filename'])
      .then(_ => res.status(204).send())
      .catch((ex: Error) => next(new RouteError(ex.message, 400)));
  }

}