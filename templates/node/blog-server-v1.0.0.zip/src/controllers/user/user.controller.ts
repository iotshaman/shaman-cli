import { Request, Response, Application, Router } from "express";
import { inject, injectable } from 'inversify';
import { IUserService } from "../../services/user.service";
import { RouteError } from "../../models/route-error";
import { ControllerBase } from "../controller.base";
import { TYPES } from "../../composition/app.composition.types";
import { IAuthService } from "../../services/auth.service";

@injectable()
export class UserController extends ControllerBase {

  private router: Router;

  constructor(
    @inject(TYPES.ExpressApplication) app: Application,
    @inject(TYPES.UserService) private userService: IUserService,
    @inject(TYPES.AuthService) authService: IAuthService) {
    super(authService);
    this.router = Router();
    this.router
      .use(this.authorize)
      .get('/', this.authorize, this.getAllUsers)
      .get('/:email', this.authorize, this.getUser)
      .put('/', this.authorize, this.addUser)
      .delete('/:email', this.authorize, this.deleteUser)
      
      app.use('/api/user', this.router);
  }

  getAllUsers = (_req: Request, res: Response, next: any) => {
    this.userService.getAllUsers()
      .then(users => res.json(users))
      .catch((ex: Error) => next(new RouteError(ex.message, 500)));
  }

  getUser = (req: Request, res: Response, next: any) => {
    if (!req.params.email) return next(new RouteError('Email not provided', 400));
    let email = req.params.email;
    this.userService.getUser(email)
      .then(user => res.json(user))
      .catch((ex: Error) => next(new RouteError(ex.message, 500)));
  }

  addUser = (req: Request, res: Response, next: any) => {
    if (!req.body.email) return next(new RouteError('Email not provided', 400));
    if (!req.body.name) return next(new RouteError('Name not provided', 400));
    if (!req.body.password) return next(new RouteError('Password not provided', 400));
    let { email, name, password } = req.body;
    this.userService.addUser(email, name, password)
      .then(user => res.json(user))
      .catch((ex: Error) => next(new RouteError(ex.message, 500)));
  }

  deleteUser = (req: Request, res: Response, next: any) => {
    if (!req.params.email) return next(new RouteError('Email not provided', 400));
    let email = req.params.email;
    this.userService.deleteUser(email)
      .then(_ => res.status(204).send())
      .catch((ex: Error) => next(new RouteError(ex.message, 500)));
  }

}