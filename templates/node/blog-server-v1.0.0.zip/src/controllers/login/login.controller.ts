import { Request, Response, Application, Router } from "express";
import { inject, injectable } from 'inversify';
import { TYPES } from "../../composition/app.composition.types";
import { RouteError } from "../../models/route-error";
import { IAuthService } from "../../services/auth.service";

@injectable()
export class LoginController {

  private router: Router;

  constructor(
    @inject(TYPES.ExpressApplication) app: Application,
    @inject(TYPES.AuthService) private authService: IAuthService) {
    this.router = Router();
    this.router
      .post('/', this.login)
      .post('/pwd', this.changePassword)

    app.use('/api/login', this.router);
  }

  login = (req: Request, res: Response, next: any) => {
    if (!req.body.email) return next(new RouteError('Email not provided', 400));
    if (!req.body.password) return next(new RouteError('Old password not provided', 400));
    let { email, password } = req.body;
    this.authService.authenticateUser(email, password)
      .then(user => {
        let accessToken = this.authService.getAccessToken(user);
        res.json({
          token: accessToken,
          temporary: user.temporaryPass
        })
      })
      .catch((ex: Error) => next(new RouteError(ex.message, 500)));
  }

  changePassword = (req: Request, res: Response, next: any) => {
    if (!req.body.email) return next(new RouteError('Email not provided', 400));
    if (!req.body.oldPassword) return next(new RouteError('Old password not provided', 400));
    if (!req.body.newPassword) return next(new RouteError('New password not provided', 400));
    let { email, oldPassword, newPassword } = req.body;
    this.authService.changePassword(email, oldPassword, newPassword)
      .then(this.authService.getAccessToken)
      .then(accessToken => res.json({ accessToken }))
      .catch((ex: Error) => next(new RouteError(ex.message, 500)));
  }

}