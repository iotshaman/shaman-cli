INSERT INTO user (
  email,
  firstName,
  lastName,
  passwordHash
)
VALUES
("system@admin.local", 'System', 'Admin', '$2a$08$C/IOdgXUfiVTyFWwu1wxr.AHU..3xbTVkJaOPs8X6t3NUUvqnOYMG');