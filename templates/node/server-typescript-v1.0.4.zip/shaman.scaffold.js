console.log("Project specs have been applied.");
process.exit(0);