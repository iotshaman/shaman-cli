//shaman: {"lifecycle": "transformation", "args": {"type": "import", "target": "*"}}

export class AppConfig {
  port: string;
  //shaman: {"lifecycle": "transformation", "args": {"type": "config", "target": "*"}}
}