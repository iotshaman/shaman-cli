export class AppConfig {
  port: string;
}