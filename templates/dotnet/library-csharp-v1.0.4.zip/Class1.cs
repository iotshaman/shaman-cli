﻿using System;

namespace Shaman.CsharpLibrary
{
    public class Class1
    {
    }
}
