﻿using System.Diagnostics.CodeAnalysis;

namespace Shaman.CsharpServer.Configuration
{
    [ExcludeFromCodeCoverage]
    public class AppConfig
    {

    }
}
