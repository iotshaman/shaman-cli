﻿using System.Diagnostics.CodeAnalysis;

namespace Shaman.CsharpServer.Configuration
{
    [ExcludeFromCodeCoverage]
    public class AppConfig
    {
		//shaman: {"lifecycle": "transformation", "args": {"type": "config", "target": "*"}}
    }
}
